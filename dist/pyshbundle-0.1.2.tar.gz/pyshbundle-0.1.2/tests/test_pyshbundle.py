#!/usr/bin/env python

"""Tests for `pyshbundle` package."""


import unittest

from pyshbundle import pyshbundle


class TestPyshbundle(unittest.TestCase):
    """Tests for `pyshbundle` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
